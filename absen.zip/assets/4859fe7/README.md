jQuery UI
=========

Shim [repository](https://github.com/components/jqueryui) for the [jQuery UI](https://jqueryui.com).

Package Managers
----------------

* [Bower](http://bower.io/): `jquery-ui`
* [Component](https://github.com/component/component): `components/jquery-ui`
* [Composer](http://packagist.org/packages/components/jquery): `components/jqueryui`
* [npm](https://www.npmjs.com/): `components-jqueryui`